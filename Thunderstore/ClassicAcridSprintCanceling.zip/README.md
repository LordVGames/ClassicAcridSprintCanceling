# ClassicAcridSprintCanceling
Before the SOTV DLC released, sprint-canceling Acrid's primary attack would make it reset the combo, meaning you would keep doing the first hit over and over. This mod re-creates that!

## Before

![output2](https://github.com/user-attachments/assets/c4b2d294-e38f-46ba-8788-794006986b55)


## After

![output1](https://github.com/user-attachments/assets/14616ad7-c723-4879-abef-df3da4e820b4)
